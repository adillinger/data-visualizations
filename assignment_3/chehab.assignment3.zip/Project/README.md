# Max Chehab Assignment 3 Writeup

## Explanation of which visual decisions you made
I decided to highlight the selected line with a black on red border. 
Using visual popout, this should immedatly get the readers attention.
I also, labeled axis's to show the reader what the data represents.

## Description of any mastery that you have attempted
I tried to modularize everything programaticaly. I did this by
creating a Canvas and Team class and accessing each as I saw fit.

I also figured out how to run processing without the packaged IDE.
If you are interested, have a look at my makefile.

I never thought I would tell anybody that I did something cool in a makefile. 
Jeeze.